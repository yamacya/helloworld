import pandas as pd
import numpy as np 

pd.options.display.max_columns=40

movie=pd.read_csv('movie.csv')
#movie_actor_director=movie[['actor_1_name','actor_2_name']]
#print(movie_actor_director.head())

#print(movie.select_dtypes(include=['int']).head())
print(movie.filter(items=['actor_1_name','asdf']).head())