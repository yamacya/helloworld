﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilterableTreeView.Concrete_Control
{
    public class MyTreeNodeEx : TreeNodeEx
    {
        public Image Picture { get; set; }
    }
}
