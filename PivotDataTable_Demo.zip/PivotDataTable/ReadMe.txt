The is a Visual Studio 2010 website Project.

Open Visual Studio 2008.
Go to File -> Open -> Website 
and then navigate to this folder to open this Website.