﻿using System;
using System.Runtime.InteropServices;
using System.ComponentModel;
using System.Windows.Forms;
using AddinExpress.MSO;
using Excel = Microsoft.Office.Interop.Excel;
using System.Data.OleDb;
using System.Data;

namespace PivotsAndSlicersDemo
{
    /// <summary>
    ///   Add-in Express Add-in Module
    /// </summary>
    [GuidAttribute("86442D79-721E-49C1-9F5B-9E0FF841C435"), ProgId("PivotsAndSlicersDemo.AddinModule")]
    public class AddinModule : AddinExpress.MSO.ADXAddinModule
    {
        public AddinModule()
        {
            Application.EnableVisualStyles();
            InitializeComponent();
            // Please add any initialization code to the AddinInitialize event handler
        }

        private ADXRibbonTab pivotsSlicersRibbonTab;
        private ADXRibbonGroup adxRibbonGroup1;
        private ADXRibbonButton insertDataRibbonButton;
        private ADXRibbonButton createPivotRibbonButton;
        private ImageList imlIcons;

        #region Component Designer generated code
        /// <summary>
        /// Required by designer
        /// </summary>
        private System.ComponentModel.IContainer components;

        /// <summary>
        /// Required by designer support - do not modify
        /// the following method
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddinModule));
            this.pivotsSlicersRibbonTab = new AddinExpress.MSO.ADXRibbonTab(this.components);
            this.adxRibbonGroup1 = new AddinExpress.MSO.ADXRibbonGroup(this.components);
            this.insertDataRibbonButton = new AddinExpress.MSO.ADXRibbonButton(this.components);
            this.createPivotRibbonButton = new AddinExpress.MSO.ADXRibbonButton(this.components);
            this.imlIcons = new System.Windows.Forms.ImageList(this.components);
            // 
            // pivotsSlicersRibbonTab
            // 
            this.pivotsSlicersRibbonTab.Caption = "Pivots & Slicers Demo";
            this.pivotsSlicersRibbonTab.Controls.Add(this.adxRibbonGroup1);
            this.pivotsSlicersRibbonTab.Id = "adxRibbonTab_67fc796f61204541b5bbce040bac03da";
            this.pivotsSlicersRibbonTab.Ribbons = AddinExpress.MSO.ADXRibbons.msrExcelWorkbook;
            // 
            // adxRibbonGroup1
            // 
            this.adxRibbonGroup1.Caption = "Data && Pivot";
            this.adxRibbonGroup1.Controls.Add(this.insertDataRibbonButton);
            this.adxRibbonGroup1.Controls.Add(this.createPivotRibbonButton);
            this.adxRibbonGroup1.Id = "adxRibbonGroup_057b19d4aad346b781aec3bcba5a5f12";
            this.adxRibbonGroup1.ImageTransparentColor = System.Drawing.Color.Transparent;
            this.adxRibbonGroup1.Ribbons = AddinExpress.MSO.ADXRibbons.msrExcelWorkbook;
            // 
            // insertDataRibbonButton
            // 
            this.insertDataRibbonButton.Caption = "Insert Data from Database";
            this.insertDataRibbonButton.Id = "adxRibbonButton_20d984f7814d4721b9b2f53a9deceeb9";
            this.insertDataRibbonButton.Image = 0;
            this.insertDataRibbonButton.ImageList = this.imlIcons;
            this.insertDataRibbonButton.ImageTransparentColor = System.Drawing.Color.Transparent;
            this.insertDataRibbonButton.Ribbons = AddinExpress.MSO.ADXRibbons.msrExcelWorkbook;
            this.insertDataRibbonButton.Size = AddinExpress.MSO.ADXRibbonXControlSize.Large;
            this.insertDataRibbonButton.OnClick += new AddinExpress.MSO.ADXRibbonOnAction_EventHandler(this.insertDataRibbonButton_OnClick);
            // 
            // createPivotRibbonButton
            // 
            this.createPivotRibbonButton.Caption = "Create Pivot with Slicers";
            this.createPivotRibbonButton.Id = "adxRibbonButton_58250e528cfb4c4aa5e84c8fcdeb49f1";
            this.createPivotRibbonButton.Image = 1;
            this.createPivotRibbonButton.ImageList = this.imlIcons;
            this.createPivotRibbonButton.ImageTransparentColor = System.Drawing.Color.Transparent;
            this.createPivotRibbonButton.Ribbons = AddinExpress.MSO.ADXRibbons.msrExcelWorkbook;
            this.createPivotRibbonButton.Size = AddinExpress.MSO.ADXRibbonXControlSize.Large;
            this.createPivotRibbonButton.OnClick += new AddinExpress.MSO.ADXRibbonOnAction_EventHandler(this.createPivotRibbonButton_OnClick);
            // 
            // imlIcons
            // 
            this.imlIcons.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imlIcons.ImageStream")));
            this.imlIcons.TransparentColor = System.Drawing.Color.Transparent;
            this.imlIcons.Images.SetKeyName(0, "1");
            this.imlIcons.Images.SetKeyName(1, "2");
            // 
            // AddinModule
            // 
            this.AddinName = "PivotsAndSlicersDemo";
            this.SupportedApps = AddinExpress.MSO.ADXOfficeHostApp.ohaExcel;

        }
        #endregion

        #region Add-in Express automatic code

        // Required by Add-in Express - do not modify
        // the methods within this region

        public override System.ComponentModel.IContainer GetContainer()
        {
            if (components == null)
                components = new System.ComponentModel.Container();
            return components;
        }

        [ComRegisterFunctionAttribute]
        public static void AddinRegister(Type t)
        {
            AddinExpress.MSO.ADXAddinModule.ADXRegister(t);
        }

        [ComUnregisterFunctionAttribute]
        public static void AddinUnregister(Type t)
        {
            AddinExpress.MSO.ADXAddinModule.ADXUnregister(t);
        }

        public override void UninstallControls()
        {
            base.UninstallControls();
        }

        #endregion

        public static new AddinModule CurrentInstance
        {
            get
            {
                return AddinExpress.MSO.ADXAddinModule.CurrentInstance as AddinModule;
            }
        }

        public Excel._Application ExcelApp
        {
            get
            {
                return (HostApplication as Excel._Application);
            }
        }

        private DataTable RetrieveSalesData()
        {
            DataSet dsData = new DataSet();
            using (OleDbConnection conn = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Data\NorthwindReports.accdb;Persist Security Info=False;"))
            {
                OleDbDataAdapter daData = new OleDbDataAdapter("Select * From SalesData", conn);
                daData.Fill(dsData);
            }
            return dsData.Tables[0];
        }

        private void insertDataRibbonButton_OnClick(object sender, IRibbonControl control, bool pressed)
        {
            Excel.Worksheet activeSheet = null;
            Excel.Range range = null;
            Excel.Range headerRange = null;
            Excel.Font headerFont = null;

            try
            {
                activeSheet = ExcelApp.ActiveSheet as Excel.Worksheet;
                string[] header = new string[] { "Month", "Product", "SalesPerson", "Units Sold" };
                headerRange = activeSheet.get_Range("A1", "D1");
                headerRange.set_Value(null, header);
                headerFont = headerRange.Font;
                headerFont.Bold = true;

                DataTable dtSalesData = RetrieveSalesData();
                int rowCount = 2;
                foreach (DataRow row in dtSalesData.Rows)
                {
                    range = activeSheet.get_Range("A" + rowCount, "D" + rowCount);
                    range.set_Value(null, row.ItemArray);
                    Marshal.ReleaseComObject(range);
                    range = null;
                    rowCount++;
                }
            }
            finally
            {
                if (activeSheet != null)
                    Marshal.ReleaseComObject(activeSheet);
                if (range != null)
                    Marshal.ReleaseComObject(range);
                if (headerRange != null)
                    Marshal.ReleaseComObject(headerRange);
                if (headerFont != null)
                    Marshal.ReleaseComObject(headerFont);
            }
        }

        private void createPivotRibbonButton_OnClick(object sender, IRibbonControl control, bool pressed)
        {
            Excel.Workbook activeWorkBook = null;
            Excel.Worksheet pivotWorkSheet = null;
            Excel.PivotCaches pivotCaches = null;
            Excel.PivotCache pivotCache = null;
            Excel.PivotTable pivotTable = null;
            Excel.PivotFields pivotFields = null;
            Excel.PivotField monthPivotField = null;
            Excel.PivotField productPivotField = null;
            Excel.PivotField salesPersonPivotField = null;
            Excel.PivotField unitsSoldPivotField = null;
            Excel.PivotField unitsSoldSumPivotField = null;

            Excel.SlicerCaches slicerCaches = null;
            Excel.SlicerCache monthSlicerCache = null;
            Excel.Slicers monthSlicers = null;
            Excel.Slicer monthSlicer = null;

            Excel.SlicerCache productSlicerCache = null;
            Excel.Slicers productSlicers = null;
            Excel.Slicer productSlicer = null;

            Excel.SlicerCache salesPersonSlicerCache = null;
            Excel.Slicers salesPersonSlicers = null;
            Excel.Slicer salesPersonSlicer = null;

            try
            {
                activeWorkBook = ExcelApp.ActiveWorkbook;
                pivotWorkSheet = (Excel.Worksheet)ExcelApp.Sheets.Add();

                // Create the Pivot Table
                pivotCaches = activeWorkBook.PivotCaches();
                pivotCache = pivotCaches.Create(Excel.XlPivotTableSourceType.xlDatabase, "Sheet1!$A$1:$D$31");
                pivotTable = pivotCache.CreatePivotTable("Sheet4!R3C1");

                // Set the Pivot Fields
                pivotFields = (Excel.PivotFields)pivotTable.PivotFields();

                // Month Pivot Field
                monthPivotField = (Excel.PivotField)pivotFields.Item("Month");
                monthPivotField.Orientation = Excel.XlPivotFieldOrientation.xlRowField;
                monthPivotField.Position = 1;

                // Product Pivot Field
                productPivotField = (Excel.PivotField)pivotFields.Item("Product");
                productPivotField.Orientation = Excel.XlPivotFieldOrientation.xlColumnField;

                // Sales Person Pivot Field
                salesPersonPivotField = (Excel.PivotField)pivotFields.Item("SalesPerson");
                salesPersonPivotField.Orientation = Excel.XlPivotFieldOrientation.xlPageField;

                // Units Sold Pivot Field
                unitsSoldPivotField = (Excel.PivotField)pivotFields.Item("Units Sold");

                // Sum of Units Sold Field
                unitsSoldSumPivotField = pivotTable.AddDataField(unitsSoldPivotField, "# Units Sold", Excel.XlConsolidationFunction.xlSum);

                slicerCaches = activeWorkBook.SlicerCaches;
                // Month Slicer
                monthSlicerCache = slicerCaches.Add(pivotTable, "Month", "Month");
                monthSlicers = monthSlicerCache.Slicers;
                monthSlicer = monthSlicers.Add(ExcelApp.ActiveSheet, Type.Missing, "Month", "Month", 160, 10, 144, 200);
                // Product Slicer
                productSlicerCache = slicerCaches.Add(pivotTable, "Product", "Product");
                productSlicers = productSlicerCache.Slicers;
                productSlicer = productSlicers.Add(ExcelApp.ActiveSheet, Type.Missing, "Product", "Product", 160, 164, 144, 200);
                // Sales Person Slicer
                salesPersonSlicerCache = slicerCaches.Add(pivotTable, "SalesPerson", "SalesPerson");
                salesPersonSlicers = salesPersonSlicerCache.Slicers;
                salesPersonSlicer = salesPersonSlicers.Add(ExcelApp.ActiveSheet, Type.Missing, "SalesPerson", "SalesPerson", 160, 318, 144, 200);
            }
            finally
            {
                if (salesPersonSlicer != null)
                    Marshal.ReleaseComObject(salesPersonSlicer);
                if (salesPersonSlicers != null)
                    Marshal.ReleaseComObject(salesPersonSlicers);
                if (salesPersonSlicerCache != null)
                    Marshal.ReleaseComObject(salesPersonSlicerCache);
                if (productSlicer != null)
                    Marshal.ReleaseComObject(productSlicer);
                if (productSlicers != null)
                    Marshal.ReleaseComObject(productSlicers);
                if (productSlicerCache != null)
                    Marshal.ReleaseComObject(productSlicerCache);
                if (monthSlicer != null)
                    Marshal.ReleaseComObject(monthSlicer);
                if (monthSlicers != null)
                    Marshal.ReleaseComObject(monthSlicers);
                if (monthSlicerCache != null)
                    Marshal.ReleaseComObject(monthSlicerCache);
                if (slicerCaches != null)
                    Marshal.ReleaseComObject(slicerCaches);
                if (unitsSoldSumPivotField != null)
                    Marshal.ReleaseComObject(unitsSoldSumPivotField);
                if (unitsSoldPivotField != null)
                    Marshal.ReleaseComObject(unitsSoldPivotField);
                if (salesPersonPivotField != null)
                    Marshal.ReleaseComObject(salesPersonPivotField);
                if (productPivotField != null)
                    Marshal.ReleaseComObject(productPivotField);
                if (monthPivotField != null)
                    Marshal.ReleaseComObject(monthPivotField);
                if (pivotFields != null)
                    Marshal.ReleaseComObject(pivotFields);
                if (pivotTable != null)
                    Marshal.ReleaseComObject(pivotTable);
                if (pivotCache != null)
                    Marshal.ReleaseComObject(pivotCache);
                if (pivotCaches != null)
                    Marshal.ReleaseComObject(pivotCaches);
                if (pivotWorkSheet != null)
                    Marshal.ReleaseComObject(pivotWorkSheet);
                if (activeWorkBook != null)
                    Marshal.ReleaseComObject(activeWorkBook);
            }
        }

    }
}

