﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Collections;
using Microsoft.Office.Tools.Excel;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;

namespace excel_search_file
{
    public partial class Search : Form
    {
        public Dictionary<string, bool> dictionary = new Dictionary<string, bool>();
        public Search()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Microsoft.Office.Tools.Excel.Workbook workbook = Globals.Factory.GetVstoObject(
            Globals.ThisAddIn.Application.ActiveWorkbook);
            string WorkbookFullName = workbook.FullName.Replace('\\', '/');
            string selectedpanfu = "";
            ExcelTool exceltool = new ExcelTool();
            bool bRet = exceltool.InitExcelTool(WorkbookFullName);
            if (!bRet)
            {
                return;
            }
            IniFile manageIniFile = exceltool.ManageIniFile;
            string section = "SkipableFolder", keyname = "skipfolder";
            for (int i = 1; i < 21; ++i)
            {
                string szkeyname = keyname + i.ToString();
                string retstring = null;
                if (manageIniFile.IsKeyExist(section, szkeyname))
                {
                    manageIniFile.GetString(section, szkeyname, out retstring);
                    dictionary[retstring] = true;
                }
                else
                    break;
            }
            selectedpanfu = exceltool.ParentFolder;
            string targetfile = textBox1.Text;

            listView1.Items.Clear();
            ListViewItem item;
            foreach (var si in SearchFile(selectedpanfu, targetfile))
            {
                string filename = System.IO.Path.GetFileName(si.szPath);
                item = listView1.Items.Add(si.szPath);
                item.SubItems.Add(filename);
            }
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Up || e.KeyCode == Keys.Down)
            {
                this.listView1.Focus();
                this.listView1.Items[0].Focused = true;
            }
        }

        private void listView1_DoubleClick(object sender, EventArgs e)
        {
            this.Close();
            if (listView1.SelectedItems.Count == 0)
            {
                return;
            }
            string fileFullPath = listView1.SelectedItems[0].Text;
            Excel_Universal_Tools.SwitchWindow(fileFullPath, Globals.ThisAddIn.Application.Workbooks);
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listView1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.listView1_DoubleClick(sender, e);
            }
        }

        private void Search_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void Search_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)27)
            {
                this.Close();
                return;
            }
        }

        private void Search_Load(object sender, EventArgs e)
        {
            this.KeyPreview = true;
            textBox1_TextChanged(sender, e);
        }

        private void Search_Activated(object sender, EventArgs e)
        {
            this.Focus();
            this.textBox1.Focus();
        }

        public class ShowInfo
        {
            public int nValue;
            public string szPath;
        }

        List<FileInfo> s_lstFile = new List<FileInfo>();
        private void InitFileList(string szRootPath)
        {
            DirectoryInfo dir = new DirectoryInfo(szRootPath);

            foreach (FileInfo file in dir.GetFiles("*.*", SearchOption.TopDirectoryOnly))
            {
                s_lstFile.Add(file);
            }

            foreach (DirectoryInfo subDir in dir.GetDirectories())
            {
                if (subDir.Name.StartsWith("."))
                    continue;
                if (!dictionary.Keys.Contains(subDir.Name))
                {
                    FileInfo[] files = subDir.GetFiles("*.*", SearchOption.AllDirectories);
                    s_lstFile.AddRange(files);
                }
            }
        }

        public List<ShowInfo> SearchFile(string onedrive, string targetFile)
        {
            if (s_lstFile.Count <= 0)
                InitFileList(onedrive);

            List<ShowInfo> directorys = new List<ShowInfo>();
            foreach (FileInfo item in s_lstFile)
            {
                if (!item.FullName.Contains(targetFile))
                    continue;
                ShowInfo si = new ShowInfo();
                si.nValue = GetValue(item.Name, item.FullName, targetFile);
                si.szPath = string.Format("{0}\\{1}", item.DirectoryName, item.Name);
                directorys.Add(si);
            }

            List<ShowInfo> lstResult = (from a in directorys orderby a.nValue descending select a).Take(30).ToList();

            return lstResult;
        }

        public int GetValue(string szFileName, string szFullPath, string szTarget)
        {
            if (szFileName.Contains(szTarget))
            {
                return 10000000 - szFileName.IndexOf(szTarget); ;
            }

            if (szFullPath.Contains(szTarget))
            {
                return 10000 - szFullPath.IndexOf(szTarget);
            }

            return 0;
        }
    }
}
