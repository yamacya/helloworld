﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.IO;

namespace excel_search_file
{
    public class IniFile : IEnumerable
    {
        string m_szFilePath = "";
        Dictionary<string, KeyValueInfo> m_dicFileInfo = null;

        class KeyValueInfo : IEnumerable
        {
            Dictionary<string, string> m_dicKeyValueInfo = new Dictionary<string, string>();
            public void AddValue(string szKey, string szValue)
            {
                m_dicKeyValueInfo[szKey] = szValue;
            }

            public bool TryGetValue(string szKey, out string szValue)
            {
                szValue = "";
                if (!m_dicKeyValueInfo.ContainsKey(szKey))
                {
                    return false;
                }

                szValue = m_dicKeyValueInfo[szKey];
                return true;
            }

            public bool IsExist(string szKey)
            {
                return m_dicKeyValueInfo.ContainsKey(szKey);
            }

            public IEnumerator GetEnumerator()
            {
                return m_dicKeyValueInfo.GetEnumerator();
            }
        }

        public IniFile()
        {
            m_dicFileInfo = new Dictionary<string, KeyValueInfo>();
        }
        public bool Load(string szFilePath, bool bIsGBK = true)
        {
            System.Text.Encoding encoding = null;
            if (bIsGBK)
            {
                encoding = new GBKEncoding();
            }

            string szFileInfo = LoadText(szFilePath, encoding);

            if (szFileInfo == null)
            {
                //Debug.LogError("load ini fail !" + szFilePath + " >>load text fail !!");
                return false;
            }

            return LoadFileFromText(szFilePath, szFileInfo);
        }

        public bool LoadFileFromText(string szFileName, string szText)
        {
            m_szFilePath = szFileName;
            szText = szText.TrimEnd(new char[] { '\t', ' ', '\n' });

            StringReader fileReader = new StringReader(szText);
            if (fileReader == null)
            {
                LogError("create stream reader fail !");
                return false;
            }

            char[] trimeSpace = { ' ', '\t' };
            string szLine = null;
            KeyValueInfo CurKeyValue = null;
            while (true)
            {
                szLine = fileReader.ReadLine();
                if (szLine == null)
                {
                    break;
                }

                szLine = szLine.TrimStart(trimeSpace);
                if (szLine.Length <= 0)
                {
                    continue;
                }

                //'#'开始的行为注释行，忽略
                if (szLine[0] == '#')
                {
                    continue;
                }

                if (szLine[0] == '[')
                {
                    int nEndIdx = szLine.IndexOf(']');
                    if (nEndIdx <= 0)
                    {
                        LogError("err line:" + szLine);
                        fileReader.Close();
                        return false;
                    }

                    string szSection = szLine.Substring(1, nEndIdx - 1);
                    if (szSection == null || szSection.Length <= 0)
                    {
                        LogError("err line:" + szLine);
                        fileReader.Close();
                        return false;
                    }

                    CurKeyValue = GetSection(szSection);
                    continue;
                }

                if (!InvalidChar(szLine[0]))
                {
                    if (CurKeyValue == null)
                        continue;

                    int nEndIdx = szLine.IndexOf('=');
                    if (nEndIdx <= 0)
                    {
                        continue;
                    }

                    string szKey = szLine.Substring(0, nEndIdx);
                    szKey = szKey.TrimStart(trimeSpace).TrimEnd(trimeSpace);
                    if (szKey == null || szKey == "")
                    {
                        continue;
                    }

                    string szValue = szLine.Substring(nEndIdx + 1);
                    szValue = szValue.TrimStart(trimeSpace).TrimEnd(trimeSpace);
                    if (szValue == null || szValue == "")
                    {
                        continue;
                    }

                    CurKeyValue.AddValue(szKey, szValue);
                }
            }
            fileReader.Close();
            return true;
        }

        private void LogError(string szInfo)
        {
            //Debug.LogError("Ini file err !!" + m_szFilePath + " >>" + szInfo);
        }

        public void Clear()
        {
            m_dicFileInfo.Clear();
        }

        private bool InvalidChar(char c)
        {
            if ("\\/:*?\"<>|\'#~!@%^&()+{}`,\a\b\f\t\v[];#=".IndexOf(c) >= 0)
                return true;

            return false;
        }

        private KeyValueInfo GetSection(string szSection)
        {
            if (!m_dicFileInfo.ContainsKey(szSection))
            {
                m_dicFileInfo[szSection] = new KeyValueInfo();
            }

            return m_dicFileInfo[szSection];
        }
        public int GetSectionCount()
        {
            return m_dicFileInfo.Count;
        }
        public bool IsSectionExist(string szSection)
        {
            return m_dicFileInfo.ContainsKey(szSection);
        }
        public bool IsKeyExist(string szSection, string szKeyName)
        {
            KeyValueInfo keyValueInfo = null;
            if (!m_dicFileInfo.TryGetValue(szSection, out keyValueInfo))
            {
                return false;
            }

            return keyValueInfo.IsExist(szKeyName);
        }

        public bool GetString(string szSection, string szKeyName, out string szRetString)
        {
            szRetString = "";
            KeyValueInfo keyValueInfo = null;
            if (!m_dicFileInfo.TryGetValue(szSection, out keyValueInfo))
            {
                return false;
            }

            if (!keyValueInfo.TryGetValue(szKeyName, out szRetString))
            {
                return false;
            }

            return true;
        }

        public bool GetMultiString(string szSection, string szKeyName, out string[] vecRetString)
        {
            vecRetString = null;

            string szValue = GetString(szSection, szKeyName);
            var trimSpace = new char[] { ' ', ',', '\t' };

            szValue = szValue.TrimStart(trimSpace);
            szValue = szValue.TrimEnd(trimSpace);

            if (szValue == null || szValue == "")
            {
                return false;
            }

            vecRetString = szValue.Split(',');
            if (vecRetString.Length <= 0)
            {
                return false;
            }

            return true;
        }

        private string GetString(string szSection, string szKeyName)
        {
            string szResult = null;
            if (!GetString(szSection, szKeyName, out szResult))
            {
                return "";
            }

            return szResult;
        }

        public bool GetInteger(string szSection, string szKeyName, out int nRetInt)
        {
            nRetInt = 0;
            if (!int.TryParse(GetString(szSection, szKeyName), out nRetInt))
            {
                return false;
            }
            return true;
        }

        public bool GetInteger(string szSection, string szKeyName, int nDef, out int nRetInt)
        {
            if (!int.TryParse(GetString(szSection, szKeyName), out nRetInt))
            {
                nRetInt = nDef;
                return false;
            }

            return true;
        }

        public bool GetInteger2(string szSection, string szKeyName, out int nRetInt1, out int nRetInt2)
        {
            nRetInt1 = 0;
            nRetInt2 = 0;
            string szValue = GetString(szSection, szKeyName);
            if (szValue == null || szValue == "")
            {
                return false;
            }

            var vecValues = szValue.Split(',');
            if (vecValues.Length != 2)
            {
                return false;
            }

            if (!int.TryParse(vecValues[0], out nRetInt1))
            {
                nRetInt1 = 0;
                nRetInt2 = 0;
                return false;
            }

            if (!int.TryParse(vecValues[1], out nRetInt2))
            {
                nRetInt1 = 0;
                nRetInt2 = 0;
                return false;
            }

            return true;
        }

        public bool GetMultiInteger(string szSection, string szKeyName, out int[] vecRetInt)
        {
            vecRetInt = null;
            string[] vecValues = null;
            if (!GetMultiString(szSection, szKeyName, out vecValues))
            {
                return false;
            }

            vecRetInt = new int[vecValues.Length];

            for (int i = 0; i < vecValues.Length; ++i)
            {
                if (!int.TryParse(vecValues[i], out vecRetInt[i]))
                {
                    for (int idx = 0; idx < vecRetInt.Length; ++idx)
                    {
                        vecRetInt[idx] = 0;
                    }
                    return false;
                }
            }

            return true;
        }

        public bool GetFloat(string szSection, string szKeyName, float fDefault, out float fRetFloat)
        {
            if (!float.TryParse(GetString(szSection, szKeyName), out fRetFloat))
            {
                fRetFloat = fDefault;
                return false;
            }

            return true;
        }

        public bool GetFloat(string szSection, string szKeyName, out float fRetFloat)
        {
            if (!float.TryParse(GetString(szSection, szKeyName), out fRetFloat))
            {
                fRetFloat = 0.0f;
                return false;
            }
            return true;
        }

        public bool GetFloat2(string szSection, string szKeyName, out float fRetFloat1, out float fRetFloat2)
        {
            fRetFloat1 = 0.0f;
            fRetFloat2 = 0.0f;

            string szValue = GetString(szSection, szKeyName);
            if (szValue == null || szValue == "")
            {
                return false;
            }

            var vecValues = szValue.Split(',');
            if (vecValues.Length != 2)
            {
                return false;
            }

            if (!float.TryParse(GetString(szSection, szKeyName), out fRetFloat1))
            {
                fRetFloat1 = 0.0f;
                fRetFloat2 = 0.0f;
                return false;
            }

            if (!float.TryParse(GetString(szSection, szKeyName), out fRetFloat2))
            {
                fRetFloat1 = 0.0f;
                fRetFloat2 = 0.0f;
                return false;
            }

            return true;
        }

        public bool GetMultiFloat(string szSection, string szKeyName, out float[] vecRetFloat)
        {
            vecRetFloat = null;
            string[] vecValues = null;
            if (!GetMultiString(szSection, szKeyName, out vecValues))
            {
                return false;
            }

            vecRetFloat = new float[vecValues.Length];
            for (int i = 0; i < vecValues.Length; ++i)
            {
                if (!float.TryParse(vecValues[i], out vecRetFloat[i]))
                {
                    for (int idx = 0; idx < vecRetFloat.Length; ++idx)
                    {
                        vecRetFloat[idx] = 0.0f;
                    }
                    return false;
                }
            }

            return true;
        }

        public bool GetBool(string szSection, string szKeyName, out bool bRetBool)
        {
            bRetBool = false;
            var szValue = GetString(szSection, szKeyName).ToLower();
            if (szValue == null || szValue == "")
            {
                return false;
            }

            if (!bool.TryParse(szValue, out bRetBool))
            {
                bRetBool = false;
                return false;
            }

            return true;
        }

        public IEnumerator GetEnumerator()
        {
            return m_dicFileInfo.GetEnumerator();
        }

        public bool SetItem(string szSection, string szKeyName, object value)
        {
            if ((szSection == null) || (szSection.Length < 1) || (szKeyName == null) || (szKeyName.Length < 1))
            {
                return false;
            }
            KeyValueInfo keyValueInfo = null;
            if (!m_dicFileInfo.TryGetValue(szSection, out keyValueInfo))
            {
                keyValueInfo = new KeyValueInfo();
                m_dicFileInfo[szSection] = keyValueInfo;
            }
            return true;
        }

        public bool SaveAs(string szFilePath, bool bIsGBK = true)
        {

            return true;
        }

        private string LoadText(string strFilePath, Encoding encoding)
        {
            string strFileText = null;
            FileStream stream = null;
            try
            {
                FileInfo file = new FileInfo(strFilePath);
                if (file.Exists)
                {
                    stream = new FileStream(strFilePath, FileMode.Open,
                        FileAccess.Read, FileShare.ReadWrite);

                    byte[] byBuffer = new byte[stream.Length];
                    stream.Read(byBuffer, 0, Convert.ToInt32(stream.Length));
                    strFileText = encoding.GetString(byBuffer);
                }
            }
            catch
            {

            }
            finally
            {
                if (stream != null)
                {
                    stream.Flush();
                    stream.Close();
                }
            }

            return strFileText;
        }
    }

}
