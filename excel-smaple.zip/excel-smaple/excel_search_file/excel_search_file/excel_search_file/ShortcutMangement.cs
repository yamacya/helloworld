﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace excel_search_file
{
    /// <summary>
    /// 用于为excel提供的快捷键绑定事件工具 可直接添加快捷键和事件就可以
    /// </summary>
    public class ShortcutManagement
    {
        public static bool s_bHotkeyUsed = false;
        public delegate void DoWork();
        private KeyEventHandler myKeyEventHandeler = null;//按键钩子
        private Hook k_hook = new Hook();
        private Keys[] ShortcutList;
        DoWork mydowork;

        public ShortcutManagement()
        {
        }
        /// <summary>
        /// 初始化ShortManagement工具
        /// </summary>
        /// <param name="Keys[] liss">使用该工具绑定的快捷键</param>
        /// <param name="DoWork dowork">使用该工具绑定的事件</param>
        /// <returns>初始化失败，返回false</returns>
        public void InitShortManagement(Keys[] list, DoWork dowork)
        {
            ShortcutList = list;
            mydowork = new DoWork(dowork);
        }
        public void startListen()
        {
            myKeyEventHandeler = new KeyEventHandler(hook_KeyDown);
            k_hook.OnKeyDown += myKeyEventHandeler;//钩住键按下
            k_hook.InstallHook();//安装键盘钩子
        }
        public void stopListen()
        {
            if (myKeyEventHandeler != null)
            {
                k_hook.OnKeyDown -= myKeyEventHandeler;//取消按键事件
                myKeyEventHandeler = null;
                k_hook.UnInstallHook();//关闭键盘钩子
            }
        }
        private void hook_KeyDown(object sender, KeyEventArgs e)
        {
            if (ShortcutList.Length == 1)
            {
                if (ShortcutList[0].ToString().Length == 1)
                {
                    if ((int)e.KeyValue == (int)ShortcutList[0])
                    {
                        mydowork();
                    }
                }
                else
                {
                    if ((int)Control.ModifierKeys == (int)ShortcutList[0])
                    {
                        mydowork();
                    }
                }
            }
            else
            {
                int singlekey = 0, combinationkey = 0;
                foreach (Keys element in ShortcutList)
                {
                    if (element.ToString().Length == 1)
                    {
                        singlekey = (int)element;
                    }
                    else
                    {
                        if (combinationkey == 0)
                            combinationkey = (int)element;
                        else
                            combinationkey |= (int)element;
                    }
                }
                if ((int)e.KeyValue == singlekey && (int)Control.ModifierKeys == combinationkey)
                {
                    mydowork();
                    s_bHotkeyUsed = true;
                }
            }
        }
    }
}
