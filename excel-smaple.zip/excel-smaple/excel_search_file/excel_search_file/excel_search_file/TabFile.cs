﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace excel_search_file
{
    public class TabFile
    {
        Dictionary<string, int> m_Title2Idx = null;
        Dictionary<int, Dictionary<int, string>> m_FileInfo = null;

        public static bool s_bIsGbk = true;

        private int m_RowCout = 0;
        public int nRowCount
        {
            get
            {
                return m_RowCout;
            }
        }

        private int m_ColumnCount = 0;
        public int nColumnCount
        {
            get
            {
                return m_ColumnCount;
            }
        }

        public TabFile()
        {
            m_Title2Idx = new Dictionary<string, int>();
            m_FileInfo = new Dictionary<int, Dictionary<int, string>>();
        }

        public bool LoadFile(string szPath)
        {
            System.Text.Encoding encoding = null;
            if (s_bIsGbk)
            {
                encoding = new GBKEncoding();
            }
            else
            {
                encoding = new UTF8Encoding();
            }

            string szFile = LoadText(szPath, encoding);
            if (szFile == null)
            {
                //Debug.LogError("load tab file fail ! " + szPath);
                return false;
            }

            bool bResult = false;
            try
            {
                bResult = LoadFileFromText(szPath, szFile);
            }
            catch (System.Exception e)
            {
                //Debug.Log("[TabFile] LoadFile Catch Exception:" + e.ToString());
            }

            return bResult;
        }

        public bool LoadFileFromText(string szPath, string szText)
        {
            szText = szText.TrimEnd(new char[] { '\r', '\t', ' ', '\n' });
            StringReader reader = new StringReader(szText);

            // 处理行首
            string szLine = reader.ReadLine();
            if (szLine == null)
            {
                reader.Close();
                return false;
            }

            m_FileInfo.Clear();
            m_Title2Idx.Clear();
            m_RowCout = 0;
            m_ColumnCount = 0;

            char[] vecTrimEnd = { '\t', ' ' };
            char[] vecSplit = { '\t' };
            szLine = szLine.TrimEnd(vecTrimEnd);

            m_FileInfo[1] = new Dictionary<int, string>();
            var vecCells = szLine.Split(vecSplit);
            ++m_RowCout;
            m_ColumnCount = m_ColumnCount > vecCells.Length ? m_ColumnCount : vecCells.Length;
            for (int i = 0; i < vecCells.Length; ++i)
            {
                if (m_Title2Idx.ContainsKey(vecCells[i]))
                {
                    //Debug.Log("load tab file err ?? title is repeat !! " + szPath + " >>" + vecCells[i]);
                }

                m_Title2Idx[vecCells[i]] = i + 1;
                m_FileInfo[1][i + 1] = vecCells[i];
            }

            // 读内容
            int nCurLine = 2;
            szLine = reader.ReadLine();
            while (szLine != null)
            {
                szLine = szLine.TrimEnd(vecTrimEnd);
                vecCells = szLine.Split(vecSplit);
                m_ColumnCount = m_ColumnCount > vecCells.Length ? m_ColumnCount : vecCells.Length;
                m_FileInfo[nCurLine] = new Dictionary<int, string>();

                for (int i = 0; i < vecCells.Length; ++i)
                {
                    m_FileInfo[nCurLine][i + 1] = vecCells[i];
                }

                ++nCurLine;
                ++m_RowCout;
                szLine = reader.ReadLine();
            }

            reader.Close();
            return true;
        }

        /// <summary>
        /// 根据列头字符串获取列下标
        /// </summary>
        /// <param name="columnString">列头字符串</param>
        /// <param name="idx">列下标,没有则返回0</param>
        /// <returns></returns>
        public bool GetColumnIdxFormString(string columnString, out int idx)
        {

            if (m_Title2Idx.TryGetValue(columnString, out idx))
                return true;
            idx = 0;
            return false;
        }

        /// <summary>
        /// 根据列下标获取该列的列头字符串
        /// </summary>
        /// <param name="idx">列下标</param>
        /// <param name="columnString">列头字符串,没有则返回""</param>
        /// <returns></returns>
        public bool GetColumnStringFormIdx(int idx, out string columnString)
        {
            columnString = "";
            foreach (var v in m_Title2Idx)
            {
                if (v.Value == idx)
                {
                    columnString = v.Key;
                    break;
                }
            }
            if (columnString == "")
                return false;
            else
                return true;
        }

        /// <summary>
        /// 根据行列号获取内容，
        /// 没有内容则返回 ""
        /// </summary>
        /// <param name="nRow">行号，从一开始</param>
        /// <param name="nColumn">列号，从一开始</param>
        /// <returns>内容，无则返回 ""</returns>
        public string GetCell(int nRow, int nColumn)
        {
            Dictionary<int, string> dicRow = null;
            if (m_FileInfo == null || !m_FileInfo.TryGetValue(nRow, out dicRow))
            {
                return "";
            }

            string szResult = null;
            if (dicRow == null || !dicRow.TryGetValue(nColumn, out szResult))
            {
                return "";
            }
            return szResult;
        }

        /// <summary>
        /// 根据行号和列头读取内容
        /// </summary>
        /// <param name="nRow">行号，从一开始</param>
        /// <param name="szColumn">列头</param>
        /// <returns>内容，无则返回 ""</returns>
        public string GetCell(int nRow, string szColumn)
        {
            int nColumn = -1;
            if (!m_Title2Idx.TryGetValue(szColumn, out nColumn))
            {
                return "";
            }
            return GetCell(nRow, nColumn);
        }

        public bool GetInteger(int nRow, string szColumn, out int nRetInteger)
        {
            if (!int.TryParse(GetCell(nRow, szColumn), out nRetInteger))
            {
                nRetInteger = 0;
                return false;
            }
            return true;
        }

        public bool GetInteger(int nRow, string szColumn, int nDef, out int nRetInteger)
        {
            if (!int.TryParse(GetCell(nRow, szColumn), out nRetInteger))
            {
                nRetInteger = nDef;
                return false;
            }

            return true;
        }

        public bool GetInteger(int nRow, int nColumn, out int nRetInteger)
        {
            if (!int.TryParse(GetCell(nRow, nColumn), out nRetInteger))
            {
                nRetInteger = 0;
                return false;
            }
            return true;
        }

        public bool GetFloat(int nRow, string szColumn, out float fRetFloat)
        {
            if (!float.TryParse(GetCell(nRow, szColumn), out fRetFloat))
            {
                fRetFloat = 0.0f;
                return false;
            }
            return true;
        }

        public bool GetFloat(int nRow, string szColumn, float fDefault, out float fRetFloat)
        {
            if (!float.TryParse(GetCell(nRow, szColumn), out fRetFloat))
            {
                fRetFloat = fDefault;
                return false;
            }
            return true;
        }

        public bool GetFloat(int nRow, int nColumn, out float fRetFloat)
        {
            if (!float.TryParse(GetCell(nRow, nColumn), out fRetFloat))
            {
                fRetFloat = 0.0f;
                return false;
            }
            return true;
        }

        public void SetCell(int nRow, int nColumn, object value)
        {
            Dictionary<int, string> dicRow = null;
            if (!m_FileInfo.TryGetValue(nRow, out dicRow))
            {
                dicRow = new Dictionary<int, string>();
                m_FileInfo[nRow] = dicRow;
            }

            dicRow[nColumn] = value.ToString();

            if (nRow == 1)
            {
                m_Title2Idx[value.ToString()] = nColumn;
            }

            m_RowCout = nRow > m_RowCout ? nRow : m_RowCout;
            m_ColumnCount = nColumn > m_ColumnCount ? nColumn : m_ColumnCount;
        }

        private byte[] GetByte(int nRow, int nColumn, bool bIsGBK)
        {
            string szInfo = GetCell(nRow, nColumn);
            if (szInfo == "")
            {
                return null;
            }

            return null;
        }

        public bool SaveAs(string filePath, bool bIsGBK = true)
        {
            if (!Path.IsPathRooted(filePath))
            {
                //return false;
            }

            FileStream fileStream = null;
            BinaryWriter writer = null;

            try
            {
                fileStream = new FileStream(filePath, FileMode.Create, FileAccess.Write,
                    FileShare.ReadWrite);
                writer = new BinaryWriter(fileStream);
                //StreamWriter writer = new StreamWriter(file);

                Dictionary<int, string> dicRow = null;

                for (int nRow = 1; nRow <= m_RowCout; ++nRow)
                {
                    string szLine = "";
                    if (m_FileInfo.TryGetValue(nRow, out dicRow))
                    {
                        for (int nColumn = 1; nColumn <= m_ColumnCount; ++nColumn)
                        {
                            szLine = szLine + GetCell(nRow, nColumn);
                            if (nColumn < m_ColumnCount)
                            {
                                szLine = szLine + "\t";
                            }
                        }
                    }

                    if (nRow < m_RowCout)
                    {
                        szLine = szLine + "\n";
                    }

                    byte[] byInfo = null;
                    if (bIsGBK)
                    {
                        byInfo = Encoding.GetEncoding("GBK").GetBytes(szLine);
                    }
                    else
                    {
                        byInfo = Encoding.GetEncoding("UTF-8").GetBytes(szLine);
                    }
                    writer.Write(byInfo);
                }
            }
            catch
            {
                return false;
            }
            finally
            {
                if (writer != null)
                {
                    writer.Flush();
                    writer.Close();
                }
                if (fileStream != null)
                {
                    fileStream.Flush();
                    fileStream.Close();
                }
            }
            return true;
        }

        public bool SaveAsWithoutNullstr(string filePath, bool bIsGBK = true)
        {
            if (!Path.IsPathRooted(filePath))
            {
                //return false;
            }

            FileStream fileStream = null;
            BinaryWriter writer = null;

            try
            {
                fileStream = new FileStream(filePath, FileMode.OpenOrCreate,
                    FileAccess.Write, FileShare.ReadWrite);
                writer = new BinaryWriter(fileStream);
                //StreamWriter writer = new StreamWriter(file);

                Dictionary<int, string> dicRow = null;

                for (int nRow = 1; nRow <= m_RowCout; ++nRow)
                {
                    string szLine = "";
                    if (m_FileInfo.TryGetValue(nRow, out dicRow))
                    {
                        for (int nColumn = 1; nColumn <= m_ColumnCount; ++nColumn)
                        {
                            string strCell = GetCell(nRow, nColumn);
                            if (strCell != null && !strCell.Trim().Equals(""))
                            {
                                szLine = szLine + strCell;
                                if (nColumn < m_ColumnCount)
                                {
                                    szLine = szLine + "\t";
                                }
                            }
                        }
                    }

                    if (szLine != null && !szLine.Trim().Equals(""))
                    {
                        if (nRow < m_RowCout)
                        {
                            szLine = szLine + "\n";
                        }

                        byte[] byInfo = null;
                        if (bIsGBK)
                        {
                            byInfo = Encoding.GetEncoding("GBK").GetBytes(szLine);
                        }
                        else
                        {
                            byInfo = Encoding.GetEncoding("UTF-8").GetBytes(szLine);
                        }
                        writer.Write(byInfo);
                    }
                }
            }
            catch
            {
                return false;
            }
            finally
            {
                if (writer != null)
                {
                    writer.Flush();
                    writer.Close();
                }
                if (fileStream != null)
                {
                    fileStream.Flush();
                    fileStream.Close();
                }
            }
            return true;
        }

        private string LoadText(string strFilePath, Encoding encoding)
        {
            string strFileText = null;
            FileStream stream = null;
            try
            {
                FileInfo file = new FileInfo(strFilePath);
                if (file.Exists)
                {
                    stream = new FileStream(strFilePath, FileMode.Open,
                        FileAccess.Read, FileShare.ReadWrite);
                    byte[] byBuffer = new byte[stream.Length];
                    stream.Read(byBuffer, 0, Convert.ToInt32(stream.Length));
                    strFileText = encoding.GetString(byBuffer).TrimEnd('\0');
                }
            }
            catch
            {

            }
            finally
            {
                if (stream != null)
                {
                    stream.Flush();
                    stream.Close();
                }
            }

            return strFileText;
        }
    }
}
