﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace excel_search_file
{
    /// <summary>
    /// 用于为excel打开的tab提供对应的manage文件，和一些简单的工具
    /// </summary>
    public class ExcelTool
    {

        private string m_parentFolder = null;
        private TabFile m_manageTabFile = null;
        private string m_WorkbookFullName = null;
        private IniFile m_manageIniFile = null;
        private readonly string m_fileOrFolderColumn = "FileOrFolder";

        /// <summary>
        /// manage.tab文件所在目录的父目录
        /// </summary>
        public string ParentFolder
        {
            get
            {
                return m_parentFolder;
            }
        }

        /// <summary>
        /// manage.tab文件的TabFile对象
        /// </summary>
        public TabFile ManageTabFile
        {
            get
            {
                return m_manageTabFile;
            }
        }

        /// <summary>
        /// manage.ini文件的IniFile对象
        /// </summary>
        public IniFile ManageIniFile
        {
            get
            {
                return m_manageIniFile;
            }
        }

        public ExcelTool()
        {
            m_manageTabFile = new TabFile();
            m_manageIniFile = new IniFile();
        }

        /// <summary>
        /// 初始化ExcelTool工具
        /// </summary>
        /// <param name="WorkbookFullName">使用该工具的Workbook的完整路径</param>
        /// <returns>初始化失败，返回false</returns>
        public bool InitExcelTool(string WorkbookFullName)
        {
            m_WorkbookFullName = WorkbookFullName.Replace('\\', '/');
            if (!GetManageFileParentFolder())
                return false;
            m_parentFolder += '/';
            if (!m_manageTabFile.LoadFile(m_parentFolder + "excel_tool_manage/manage.tab"))
                return false;
            if (!m_manageIniFile.Load(m_parentFolder + "excel_tool_manage/manage.ini"))
                return false;
            return true;
        }

        /// <summary>
        /// 获取excel_tool_manage目录的父目录
        /// </summary>
        /// <returns>如果该条路径上不存在文件夹excel_tool_manage，返回false</returns>
        private bool GetManageFileParentFolder()
        {
            string manageFolder = "/excel_tool_manage";
            string manageFilePath = m_WorkbookFullName;
            while (GetParentPath(manageFilePath, out m_parentFolder))
            {
                if (System.IO.Directory.Exists(m_parentFolder + manageFolder))
                    return true;
                manageFilePath = m_parentFolder;
            }
            return false;
        }

        /// <summary>
        /// 获取该目录的父目录，默认资源路径符为/
        /// </summary>
        /// <param name="path">目前的目录(结尾不能为/)</param>
        /// <param name="parentPath">该目录的父目录</param>
        /// <returns>如果该目录不存在父目录返回false</returns>
        private bool GetParentPath(string path, out string parentPath)
        {
            int index = path.LastIndexOf('/');
            if (index == -1)
            {
                parentPath = null;
                return false;
            }
            parentPath = path.Substring(0, index);
            return true;
        }

        /// <summary>
        /// 获取该tab文件在manage.tab文件中行号，如该文件不存在返回0(可能会有性能损耗)
        /// </summary>
        /// <param name="columnHead">列头字符串</param>
        /// <param name="content">需要查询的内容</param>
        /// <returns>该tab文件在manage.tab文件中行号，如该文件不存在返回0</returns>
        public bool GetFileAboutTheColumn(string columnHead, out string content)
        {
            Dictionary<string, string> allFileInManage = GetAllFilesAboutTheColumn(columnHead);
            if (!allFileInManage.TryGetValue(m_WorkbookFullName, out content))
                return false;
            return true;
        }

        /// <summary>
        /// 获取manageFile中所有的文件和该文件对应的columnString列组成的Dictionary<string, string>
        /// </summary>
        /// <param name="manageFolderParent">manageFile文件所在目录的父目录</param>
        /// <param name="columnString">列头字符串</param>
        /// <returns>manageFile中所有的文件和该文件对应的columnString列组成的Dictionary<string, string></returns>
        public Dictionary<string, string> GetAllFilesAboutTheColumn(string columnString)
        {
            Dictionary<string, string> fileAndFolderInManage = new Dictionary<string, string>();
            int manageRowCount = m_manageTabFile.nRowCount;
            string fileAndFolderName = null;
            string tempContent = null;
            for (int manageRowIndex = 2; manageRowIndex <= manageRowCount; ++manageRowIndex)
            {
                fileAndFolderName = m_manageTabFile.GetCell(manageRowIndex, m_fileOrFolderColumn);
                if (String.IsNullOrEmpty(fileAndFolderName))
                    continue;
                fileAndFolderName = m_parentFolder + fileAndFolderName;
                if (!fileAndFolderInManage.ContainsKey(fileAndFolderName))
                {
                    tempContent = m_manageTabFile.GetCell(manageRowIndex, columnString);
                    fileAndFolderInManage.Add(fileAndFolderName, tempContent);
                }
            }

            Dictionary<string, string> allFileInManage = new Dictionary<string, string>();
            foreach (var fileAndFolder in fileAndFolderInManage)
            {
                if (System.IO.File.Exists(fileAndFolder.Key))
                    if (!allFileInManage.ContainsKey(fileAndFolder.Key))
                        allFileInManage.Add(fileAndFolder.Key, fileAndFolder.Value);
            }

            string[] tempArray = null;
            foreach (var fileAndFolder in fileAndFolderInManage)
            {
                if (!System.IO.Directory.Exists(fileAndFolder.Key))
                    continue;
                tempArray = System.IO.Directory.GetFiles(fileAndFolder.Key).Where(
                    s => System.IO.Path.GetExtension(s) == ".tab").ToArray();
                foreach (var fileName in tempArray)
                {
                    if (!allFileInManage.ContainsKey(fileName))
                        allFileInManage.Add(fileName, fileAndFolder.Value);
                }
            }

            TabFile settingFile = new TabFile();
            foreach (var fileAndFolder in fileAndFolderInManage)
            {
                tempArray = fileAndFolder.Key.Split('|');
                if (tempArray.Length < 2)
                    continue;
                if (!settingFile.LoadFile(tempArray[0]))
                    continue;
                int settingFileRowCount = settingFile.nRowCount;
                string tempFileName = null;
                for (int settingFileRow = 2; settingFileRow <= settingFileRowCount; ++settingFileRow)
                {
                    tempFileName = m_parentFolder + settingFile.GetCell(settingFileRow, tempArray[1]);
                    if (!System.IO.File.Exists(tempFileName))
                        continue;
                    if (!allFileInManage.ContainsKey(tempFileName))
                        allFileInManage.Add(tempFileName, fileAndFolder.Value);
                }
            }

            return allFileInManage;
        }
    }
}
