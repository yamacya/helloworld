﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using Excel = Microsoft.Office.Interop.Excel;
using Office = Microsoft.Office.Core;
using Microsoft.Office.Tools.Excel;
using System.Windows.Forms;

namespace excel_search_file
{
    public partial class ThisAddIn
    {
        private static Search m_search = null;
        public void ResponseFunction()
        {
            if (m_search == null)
            {
                m_search = new Search();

                Microsoft.Office.Interop.Excel.Application application = Globals.ThisAddIn.Application;
                double x = application.Left + application.Width * 0.5;
                double y = application.Top + application.Height * 0.5;
                m_search.Location = new System.Drawing.Point((int)x, (int)y);

                m_search.FormClosing += form_FormClosing;
                Win32WindowImpl win32WindowImpl = new Win32WindowImpl(Globals.ThisAddIn.Application.Hwnd);
                m_search.Show(win32WindowImpl);
                m_search.Focus();
            }
            else
            {
                m_search.Activate();
            }
        }

        void form_FormClosing(object sender, System.Windows.Forms.FormClosingEventArgs e)
        {
            m_search = null;
        }

        ShortcutManagement shortcutmanagement = new ShortcutManagement();
        private void ThisAddIn_Startup(object sender, System.EventArgs e)
        {
            Keys[] Shortcutlist = new Keys[] { Keys.O, Keys.Alt, Keys.Shift };

            shortcutmanagement.InitShortManagement(Shortcutlist, ResponseFunction);
            shortcutmanagement.startListen();
        }

        private void ThisAddIn_Shutdown(object sender, System.EventArgs e)
        {
            //shortcutmanagement.stopListen();
        }
        #region VSTO 生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(ThisAddIn_Startup);
            this.Shutdown += new System.EventHandler(ThisAddIn_Shutdown);
        }

        #endregion
    }
}
