﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace excel_search_file
{
    public class Win32WindowImpl : System.Windows.Forms.IWin32Window
    {
        private System.IntPtr m_handle;

        public Win32WindowImpl(System.IntPtr handle)
        {
            this.m_handle = handle;
        }

        public Win32WindowImpl(int handle)
        {
            this.m_handle = new IntPtr(handle);
        }

        public IntPtr Handle
        {
            get
            {
                return m_handle;
            }
        }
    }
}
