﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Collections;
using Microsoft.Office.Tools.Excel;
using Excel = Microsoft.Office.Interop.Excel;

namespace excel_search_file
{
    /// <summary>
    /// 用于excel通用工具的一个集合
    /// </summary>
    public class Excel_Universal_Tools
    {
        /// <summary>
        /// 切换excel窗口
        /// </summary>
        /// <param name="fileFullPath">要切换的文件的绝对路径</param>
        /// <param name="WorkbookFullName">当前工作簿的整个workbook</param>
        public static void SwitchWindow(string fileFullPath, Microsoft.Office.Interop.Excel.Workbooks workbook)
        {
            int count = workbook.Count;
            bool foundflag = false;
            fileFullPath = fileFullPath.Replace('\\', '/');
            foreach (Microsoft.Office.Interop.Excel._Workbook wb in workbook)
            {
                string WorkbookFullName = wb.FullName.Replace('\\', '/');
                if (WorkbookFullName == fileFullPath)
                {
                    wb.Activate();
                    foundflag = true;
                    break;
                }
            }
            if (!foundflag)
            {
                workbook.Open(fileFullPath);
            }
        }
    }
}
