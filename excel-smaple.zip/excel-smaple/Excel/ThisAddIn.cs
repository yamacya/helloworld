﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using Excel = Microsoft.Office.Interop.Excel;
using Office = Microsoft.Office.Core;
using Microsoft.Office.Tools.Excel;
using System.Windows.Forms;
using System.IO;
using System.Runtime.InteropServices;

namespace Excel自动保存
{
    public partial class ThisAddIn
    {
        private void ThisAddIn_Startup(object sender, System.EventArgs e)
        {
            //MessageBox.Show(System.AppDomain.CurrentDomain.BaseDirectory);
            if (!File.Exists(System.AppDomain.CurrentDomain.BaseDirectory + "XLSSavePlus.ini"))
            {
                using (FileStream myFs = new FileStream(System.AppDomain.CurrentDomain.BaseDirectory + "XLSSavePlus.ini", FileMode.Create)) { }
                IniFile f = new IniFile(System.AppDomain.CurrentDomain.BaseDirectory + "XLSSavePlus.ini");
                f.WriteContentValue("首选项", "启动", "0");
                f.WriteContentValue("首选项", "弹窗", "0");
                f.WriteContentValue("首选项", "保存时间间隔", "60000");
                f.WriteContentValue("首选项", "保存文件数", "2");
                f.WriteContentValue("首选项", "永久保存文件", "0");
                f.WriteContentValue("首选项", "永久文件间隔", "9000000");
                f.WriteContentValue("首选项", "保存原始文件", "1");
                f.WriteContentValue("首选项", "路径", "D:\\officeback\\XLSsave\\");
                Globals.Ribbons.Ribbon1.时钟1.Interval = 60000;
                Globals.Ribbons.Ribbon1.时钟1.Enabled = false;
                Globals.Ribbons.Ribbon1.选择框_启动自动保存.Checked = false;
                Globals.Ribbons.Ribbon1.时钟2.Enabled = false;
                Globals.Ribbons.Ribbon1.时钟2.Interval = 1200000;
                全局变量.临时文件个数 = 2;
                全局变量.临时保存文件夹 = "D:\\officeback\\XLSsave\\";
                Globals.Ribbons.Ribbon1.文件数.Text = "2";
                Globals.Ribbons.Ribbon1.间隔时间.Text = "1分钟";
                Globals.Ribbons.Ribbon1.选择框_启动自动保存.Checked = false;
                Globals.Ribbons.Ribbon1.保存原始文件.Checked = true;
                Globals.Ribbons.Ribbon1.时钟3.Enabled = false;
                Globals.Ribbons.Ribbon1.启动永久.Checked = false;
                Globals.Ribbons.Ribbon1.永久保存间隔.Text = "2小时30分";
                弹窗说明 u = new 弹窗说明(); u.ShowDialog();//弹窗

            }
            else
            {
                IniFile f = new IniFile(System.AppDomain.CurrentDomain.BaseDirectory + "XLSSavePlus.ini");
                int x = int.Parse(f.ReadContentValue("首选项", "保存时间间隔"));
                if (x != 30000 && x != 60000 && x != 90000 && x != 120000 && x != 150000 && x != 180000 && x != 210000 && x != 240000 && x != 270000 && x != 300000) { x = 60000; }
                Globals.Ribbons.Ribbon1.时钟1.Interval = x;
                if (x == 30000) { Globals.Ribbons.Ribbon1.间隔时间.Text = "30秒"; }
                else if (x == 60000) { Globals.Ribbons.Ribbon1.间隔时间.Text = "1分钟"; }
                else if (x == 90000) { Globals.Ribbons.Ribbon1.间隔时间.Text = "1分30秒"; }
                else if (x == 120000) { Globals.Ribbons.Ribbon1.间隔时间.Text = "2分钟"; }
                else if (x == 150000) { Globals.Ribbons.Ribbon1.间隔时间.Text = "2分30秒"; }
                else if (x == 180000) { Globals.Ribbons.Ribbon1.间隔时间.Text = "3分钟"; }
                else if (x == 210000) { Globals.Ribbons.Ribbon1.间隔时间.Text = "3分30秒"; }
                else if (x == 240000) { Globals.Ribbons.Ribbon1.间隔时间.Text = "4分钟"; }
                else if (x == 270000) { Globals.Ribbons.Ribbon1.间隔时间.Text = "4分30秒"; }
                else if (x == 300000) { Globals.Ribbons.Ribbon1.间隔时间.Text = "5分钟"; }
                x = int.Parse(f.ReadContentValue("首选项", "永久文件间隔"));
                if (x != 1800000 && x != 3600000 && x != 5400000 && x != 7200000 && x != 9000000 && x != 10800000 && x != 12600000 && x != 14400000 && x != 16200000 && x != 18000000) { x = 9000000; }
                Globals.Ribbons.Ribbon1.时钟2.Interval = x;
                if (x == 1800000) { Globals.Ribbons.Ribbon1.永久保存间隔.Text = "30分钟"; }
                else if (x == 3600000) { Globals.Ribbons.Ribbon1.永久保存间隔.Text = "1小时"; }
                else if (x == 5400000) { Globals.Ribbons.Ribbon1.永久保存间隔.Text = "1小时30分钟"; }
                else if (x == 7200000) { Globals.Ribbons.Ribbon1.永久保存间隔.Text = "2小时"; }
                else if (x == 9000000) { Globals.Ribbons.Ribbon1.永久保存间隔.Text = "2小时30分钟"; }
                else if (x == 10800000) { Globals.Ribbons.Ribbon1.永久保存间隔.Text = "3小时"; }
                else if (x == 12600000) { Globals.Ribbons.Ribbon1.永久保存间隔.Text = "3小时30分钟"; }
                else if (x == 14400000) { Globals.Ribbons.Ribbon1.永久保存间隔.Text = "4小时"; }
                else if (x == 16200000) { Globals.Ribbons.Ribbon1.永久保存间隔.Text = "4小时30分钟"; }
                else if (x == 18000000) { Globals.Ribbons.Ribbon1.永久保存间隔.Text = "5小时"; }
                if (f.ReadContentValue("首选项", "启动") == "0")
                {
                    Globals.Ribbons.Ribbon1.时钟1.Enabled = false;
                    Globals.Ribbons.Ribbon1.选择框_启动自动保存.Checked = false;
                    Globals.Ribbons.Ribbon1.时钟3.Enabled = false;
                    if (f.ReadContentValue("首选项", "保存原始文件") == "1")
                    { Globals.Ribbons.Ribbon1.保存原始文件.Checked = true; }
                    else
                    { Globals.Ribbons.Ribbon1.保存原始文件.Checked = false; }
                }
                else
                {
                    Globals.Ribbons.Ribbon1.时钟1.Enabled = true;
                    Globals.Ribbons.Ribbon1.选择框_启动自动保存.Checked = true;
                    if (f.ReadContentValue("首选项", "保存原始文件") == "1")
                    {
                        Globals.Ribbons.Ribbon1.时钟3.Enabled = true;
                        Globals.Ribbons.Ribbon1.保存原始文件.Checked = true;
                    }
                    else
                    {
                        Globals.Ribbons.Ribbon1.时钟3.Enabled = false;
                        Globals.Ribbons.Ribbon1.保存原始文件.Checked = false;

                    }

                }
                全局变量.临时文件个数 = int.Parse(f.ReadContentValue("首选项", "保存文件数"));
                Globals.Ribbons.Ribbon1.文件数.Text = 全局变量.临时文件个数.ToString();
                Globals.Ribbons.Ribbon1.时钟2.Interval = int.Parse(f.ReadContentValue("首选项", "永久文件间隔"));
                if (f.ReadContentValue("首选项", "永久保存文件") == "0") { Globals.Ribbons.Ribbon1.时钟2.Enabled = false; } else { Globals.Ribbons.Ribbon1.时钟2.Enabled = true; }
                全局变量.临时保存文件夹 = f.ReadContentValue("首选项", "路径");
                if (f.ReadContentValue("首选项", "弹窗") == "0") { 弹窗说明 u = new 弹窗说明(); u.ShowDialog(); }
            }


        }

        private void ThisAddIn_Shutdown(object sender, System.EventArgs e)
        {
        }

        #region VSTO 生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(ThisAddIn_Startup);
            this.Shutdown += new System.EventHandler(ThisAddIn_Shutdown);
        }
        
        #endregion
    }
    public class 全局变量
    {
        public static string[] 文件名合集 = null;
        public static string 临时保存文件夹;
        public static int 临时文件个数;
        public static int 永久保存识别码 = 0;
    }

    public class IniFile//读ini文件必要核心代码
    {
        public string Path;

        public IniFile(string path)
        {
            this.Path = path;
        }

        /// <summary>
        /// 写入INI文件
        /// </summary>
        /// <param name="section">节点名称[如[TypeName]]</param>
        /// <param name="key">键</param>
        /// <param name="val">值</param>
        /// <param name="filepath">文件路径</param>
        /// <returns></returns>
        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string section, string key, string val, string filepath);

        /// <summary>
        /// 读取INI文件
        /// </summary>
        /// <param name="section">节点名称</param>
        /// <param name="key">键</param>
        /// <param name="def">值</param>
        /// <param name="retval">stringbulider对象</param>
        /// <param name="size">字节大小</param>
        /// <param name="filePath">文件路径</param>
        /// <returns></returns>
        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retval, int size, string filePath);

        /// <summary>
        /// 写入
        /// </summary>
        /// <param name="section"></param>
        /// <param name="key"></param>
        /// <param name="iValue"></param>
        public void WriteContentValue(string section, string key, string iValue)
        {
            WritePrivateProfileString(section, key, iValue, this.Path);
        }

        /// <summary>
        /// 读取INI文件中的内容方法
        /// </summary>
        /// <param name="Section">键</param>
        /// <param name="key">值</param>
        /// <returns></returns>
        public string ReadContentValue(string Section, string key)
        {
            StringBuilder temp = new StringBuilder(1024);
            GetPrivateProfileString(Section, key, "", temp, 1024, this.Path);
            return temp.ToString();
        }
    }

}
