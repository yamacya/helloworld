﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Excel自动保存
{
    public partial class 弹窗说明 : Form
    {
        public 弹窗说明()
        {
            InitializeComponent();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            IniFile f = new IniFile(System.AppDomain.CurrentDomain.BaseDirectory + "XLSSavePlus.ini");
            if (checkBox1.Checked) { f.WriteContentValue("首选项", "弹窗", "1"); } else { f.WriteContentValue("首选项", "弹窗", "0"); }

        }

        private void 启动功能_Click(object sender, EventArgs e)
        {
            Globals.Ribbons.Ribbon1.时钟1.Enabled = true;
            Globals.Ribbons.Ribbon1.选择框_启动自动保存.Checked = true;
            IniFile f = new IniFile(System.AppDomain.CurrentDomain.BaseDirectory + "XLSSavePlus.ini");
            f.WriteContentValue("首选项", "启动", "1");
            this.Close();

        }

        private void 不启动_Click(object sender, EventArgs e)
        {
            Globals.Ribbons.Ribbon1.时钟1.Enabled = false;
            Globals.Ribbons.Ribbon1.选择框_启动自动保存.Checked = false;
            IniFile f = new IniFile(System.AppDomain.CurrentDomain.BaseDirectory + "XLSSavePlus.ini");
            f.WriteContentValue("首选项", "启动", "0");
            this.Close();

        }

        private void 弹窗说明_Load(object sender, EventArgs e)
        {
            IniFile f = new IniFile(System.AppDomain.CurrentDomain.BaseDirectory + "XLSSavePlus.ini");
            if (f.ReadContentValue("首选项", "弹窗") == "0") { checkBox1.Checked = false; } else { checkBox1.Checked = true; }

        }
    }
}
