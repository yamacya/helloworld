﻿
namespace Excel自动保存
{
    partial class Ribbon1 : Microsoft.Office.Tools.Ribbon.RibbonBase
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        public Ribbon1()
            : base(Globals.Factory.GetRibbonFactory())
        {
            InitializeComponent();
        }

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Office.Tools.Ribbon.RibbonDropDownItem ribbonDropDownItemImpl1 = this.Factory.CreateRibbonDropDownItem();
            Microsoft.Office.Tools.Ribbon.RibbonDropDownItem ribbonDropDownItemImpl2 = this.Factory.CreateRibbonDropDownItem();
            Microsoft.Office.Tools.Ribbon.RibbonDropDownItem ribbonDropDownItemImpl3 = this.Factory.CreateRibbonDropDownItem();
            Microsoft.Office.Tools.Ribbon.RibbonDropDownItem ribbonDropDownItemImpl4 = this.Factory.CreateRibbonDropDownItem();
            Microsoft.Office.Tools.Ribbon.RibbonDropDownItem ribbonDropDownItemImpl5 = this.Factory.CreateRibbonDropDownItem();
            Microsoft.Office.Tools.Ribbon.RibbonDropDownItem ribbonDropDownItemImpl6 = this.Factory.CreateRibbonDropDownItem();
            Microsoft.Office.Tools.Ribbon.RibbonDropDownItem ribbonDropDownItemImpl7 = this.Factory.CreateRibbonDropDownItem();
            Microsoft.Office.Tools.Ribbon.RibbonDropDownItem ribbonDropDownItemImpl8 = this.Factory.CreateRibbonDropDownItem();
            Microsoft.Office.Tools.Ribbon.RibbonDropDownItem ribbonDropDownItemImpl9 = this.Factory.CreateRibbonDropDownItem();
            Microsoft.Office.Tools.Ribbon.RibbonDropDownItem ribbonDropDownItemImpl10 = this.Factory.CreateRibbonDropDownItem();
            Microsoft.Office.Tools.Ribbon.RibbonDropDownItem ribbonDropDownItemImpl11 = this.Factory.CreateRibbonDropDownItem();
            Microsoft.Office.Tools.Ribbon.RibbonDropDownItem ribbonDropDownItemImpl12 = this.Factory.CreateRibbonDropDownItem();
            Microsoft.Office.Tools.Ribbon.RibbonDropDownItem ribbonDropDownItemImpl13 = this.Factory.CreateRibbonDropDownItem();
            Microsoft.Office.Tools.Ribbon.RibbonDropDownItem ribbonDropDownItemImpl14 = this.Factory.CreateRibbonDropDownItem();
            Microsoft.Office.Tools.Ribbon.RibbonDropDownItem ribbonDropDownItemImpl15 = this.Factory.CreateRibbonDropDownItem();
            Microsoft.Office.Tools.Ribbon.RibbonDropDownItem ribbonDropDownItemImpl16 = this.Factory.CreateRibbonDropDownItem();
            Microsoft.Office.Tools.Ribbon.RibbonDropDownItem ribbonDropDownItemImpl17 = this.Factory.CreateRibbonDropDownItem();
            Microsoft.Office.Tools.Ribbon.RibbonDropDownItem ribbonDropDownItemImpl18 = this.Factory.CreateRibbonDropDownItem();
            Microsoft.Office.Tools.Ribbon.RibbonDropDownItem ribbonDropDownItemImpl19 = this.Factory.CreateRibbonDropDownItem();
            Microsoft.Office.Tools.Ribbon.RibbonDropDownItem ribbonDropDownItemImpl20 = this.Factory.CreateRibbonDropDownItem();
            Microsoft.Office.Tools.Ribbon.RibbonDropDownItem ribbonDropDownItemImpl21 = this.Factory.CreateRibbonDropDownItem();
            Microsoft.Office.Tools.Ribbon.RibbonDropDownItem ribbonDropDownItemImpl22 = this.Factory.CreateRibbonDropDownItem();
            Microsoft.Office.Tools.Ribbon.RibbonDropDownItem ribbonDropDownItemImpl23 = this.Factory.CreateRibbonDropDownItem();
            Microsoft.Office.Tools.Ribbon.RibbonDropDownItem ribbonDropDownItemImpl24 = this.Factory.CreateRibbonDropDownItem();
            Microsoft.Office.Tools.Ribbon.RibbonDropDownItem ribbonDropDownItemImpl25 = this.Factory.CreateRibbonDropDownItem();
            Microsoft.Office.Tools.Ribbon.RibbonDropDownItem ribbonDropDownItemImpl26 = this.Factory.CreateRibbonDropDownItem();
            Microsoft.Office.Tools.Ribbon.RibbonDropDownItem ribbonDropDownItemImpl27 = this.Factory.CreateRibbonDropDownItem();
            Microsoft.Office.Tools.Ribbon.RibbonDropDownItem ribbonDropDownItemImpl28 = this.Factory.CreateRibbonDropDownItem();
            Microsoft.Office.Tools.Ribbon.RibbonDropDownItem ribbonDropDownItemImpl29 = this.Factory.CreateRibbonDropDownItem();
            Microsoft.Office.Tools.Ribbon.RibbonDropDownItem ribbonDropDownItemImpl30 = this.Factory.CreateRibbonDropDownItem();
            this.自动保存P = this.Factory.CreateRibbonTab();
            this.组件_首选项 = this.Factory.CreateRibbonGroup();
            this.选择框_启动自动保存 = this.Factory.CreateRibbonCheckBox();
            this.打开保存文件夹 = this.Factory.CreateRibbonButton();
            this.设置 = this.Factory.CreateRibbonButton();
            this.选项1 = this.Factory.CreateRibbonGroup();
            this.文件数 = this.Factory.CreateRibbonComboBox();
            this.间隔时间 = this.Factory.CreateRibbonComboBox();
            this.保存位置 = this.Factory.CreateRibbonButton();
            this.选项2 = this.Factory.CreateRibbonGroup();
            this.启动永久 = this.Factory.CreateRibbonCheckBox();
            this.永久保存间隔 = this.Factory.CreateRibbonComboBox();
            this.保存原始文件 = this.Factory.CreateRibbonCheckBox();
            this.关于 = this.Factory.CreateRibbonGroup();
            this.按钮_帮助 = this.Factory.CreateRibbonButton();
            this.打开配置文件 = this.Factory.CreateRibbonButton();
            this.时钟1 = new System.Windows.Forms.Timer(this.components);
            this.时钟2 = new System.Windows.Forms.Timer(this.components);
            this.文件夹对话框 = new System.Windows.Forms.FolderBrowserDialog();
            this.时钟3 = new System.Windows.Forms.Timer(this.components);
            this.自动保存P.SuspendLayout();
            this.组件_首选项.SuspendLayout();
            this.选项1.SuspendLayout();
            this.选项2.SuspendLayout();
            this.关于.SuspendLayout();
            this.SuspendLayout();
            // 
            // 自动保存P
            // 
            this.自动保存P.Groups.Add(this.组件_首选项);
            this.自动保存P.Groups.Add(this.选项1);
            this.自动保存P.Groups.Add(this.选项2);
            this.自动保存P.Groups.Add(this.关于);
            this.自动保存P.Label = "自动保存";
            this.自动保存P.Name = "自动保存P";
            // 
            // 组件_首选项
            // 
            this.组件_首选项.Items.Add(this.选择框_启动自动保存);
            this.组件_首选项.Items.Add(this.打开保存文件夹);
            this.组件_首选项.Items.Add(this.设置);
            this.组件_首选项.Label = "首选项";
            this.组件_首选项.Name = "组件_首选项";
            // 
            // 选择框_启动自动保存
            // 
            this.选择框_启动自动保存.Label = "启动自动保存";
            this.选择框_启动自动保存.Name = "选择框_启动自动保存";
            this.选择框_启动自动保存.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.选择框_启动自动保存_Click);
            // 
            // 打开保存文件夹
            // 
            this.打开保存文件夹.Label = "打开保存文件夹";
            this.打开保存文件夹.Name = "打开保存文件夹";
            this.打开保存文件夹.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.打开保存文件夹_Click);
            // 
            // 设置
            // 
            this.设置.Label = "设置保存参数";
            this.设置.Name = "设置";
            this.设置.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.设置_Click);
            // 
            // 选项1
            // 
            this.选项1.Items.Add(this.文件数);
            this.选项1.Items.Add(this.间隔时间);
            this.选项1.Items.Add(this.保存位置);
            this.选项1.Label = "临时保存选项";
            this.选项1.Name = "选项1";
            // 
            // 文件数
            // 
            this.文件数.Enabled = false;
            ribbonDropDownItemImpl1.Label = "1";
            ribbonDropDownItemImpl2.Label = "2";
            ribbonDropDownItemImpl3.Label = "3";
            ribbonDropDownItemImpl4.Label = "4";
            ribbonDropDownItemImpl5.Label = "5";
            ribbonDropDownItemImpl6.Label = "6";
            ribbonDropDownItemImpl7.Label = "7";
            ribbonDropDownItemImpl8.Label = "8";
            ribbonDropDownItemImpl9.Label = "9";
            ribbonDropDownItemImpl10.Label = "10";
            this.文件数.Items.Add(ribbonDropDownItemImpl1);
            this.文件数.Items.Add(ribbonDropDownItemImpl2);
            this.文件数.Items.Add(ribbonDropDownItemImpl3);
            this.文件数.Items.Add(ribbonDropDownItemImpl4);
            this.文件数.Items.Add(ribbonDropDownItemImpl5);
            this.文件数.Items.Add(ribbonDropDownItemImpl6);
            this.文件数.Items.Add(ribbonDropDownItemImpl7);
            this.文件数.Items.Add(ribbonDropDownItemImpl8);
            this.文件数.Items.Add(ribbonDropDownItemImpl9);
            this.文件数.Items.Add(ribbonDropDownItemImpl10);
            this.文件数.Label = "保存文件个数";
            this.文件数.Name = "文件数";
            this.文件数.Text = "2";
            this.文件数.TextChanged += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.文件数_TextChanged);
            // 
            // 间隔时间
            // 
            this.间隔时间.Enabled = false;
            ribbonDropDownItemImpl11.Label = "30秒";
            ribbonDropDownItemImpl12.Label = "1分钟";
            ribbonDropDownItemImpl13.Label = "1分30秒";
            ribbonDropDownItemImpl14.Label = "2分钟";
            ribbonDropDownItemImpl15.Label = "2分30秒";
            ribbonDropDownItemImpl16.Label = "3分钟";
            ribbonDropDownItemImpl17.Label = "3分30秒";
            ribbonDropDownItemImpl18.Label = "4分钟";
            ribbonDropDownItemImpl19.Label = "4分30秒";
            ribbonDropDownItemImpl20.Label = "5分钟";
            this.间隔时间.Items.Add(ribbonDropDownItemImpl11);
            this.间隔时间.Items.Add(ribbonDropDownItemImpl12);
            this.间隔时间.Items.Add(ribbonDropDownItemImpl13);
            this.间隔时间.Items.Add(ribbonDropDownItemImpl14);
            this.间隔时间.Items.Add(ribbonDropDownItemImpl15);
            this.间隔时间.Items.Add(ribbonDropDownItemImpl16);
            this.间隔时间.Items.Add(ribbonDropDownItemImpl17);
            this.间隔时间.Items.Add(ribbonDropDownItemImpl18);
            this.间隔时间.Items.Add(ribbonDropDownItemImpl19);
            this.间隔时间.Items.Add(ribbonDropDownItemImpl20);
            this.间隔时间.Label = "保存间隔时间";
            this.间隔时间.Name = "间隔时间";
            this.间隔时间.Text = null;
            this.间隔时间.TextChanged += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.间隔时间_TextChanged);
            // 
            // 保存位置
            // 
            this.保存位置.Enabled = false;
            this.保存位置.Label = "选择保存文件夹";
            this.保存位置.Name = "保存位置";
            this.保存位置.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.保存位置_Click);
            // 
            // 选项2
            // 
            this.选项2.Items.Add(this.启动永久);
            this.选项2.Items.Add(this.永久保存间隔);
            this.选项2.Items.Add(this.保存原始文件);
            this.选项2.Label = "永久保存选项";
            this.选项2.Name = "选项2";
            // 
            // 启动永久
            // 
            this.启动永久.Enabled = false;
            this.启动永久.Label = "启动永久保存";
            this.启动永久.Name = "启动永久";
            this.启动永久.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.启动永久_Click);
            // 
            // 永久保存间隔
            // 
            this.永久保存间隔.Enabled = false;
            ribbonDropDownItemImpl21.Label = "30分钟";
            ribbonDropDownItemImpl22.Label = "1小时";
            ribbonDropDownItemImpl23.Label = "1小时30分钟";
            ribbonDropDownItemImpl24.Label = "2小时";
            ribbonDropDownItemImpl25.Label = "2小时30分钟";
            ribbonDropDownItemImpl26.Label = "3小时";
            ribbonDropDownItemImpl27.Label = "3小时30分钟";
            ribbonDropDownItemImpl28.Label = "4小时";
            ribbonDropDownItemImpl29.Label = "4小时30分钟";
            ribbonDropDownItemImpl30.Label = "5小时";
            this.永久保存间隔.Items.Add(ribbonDropDownItemImpl21);
            this.永久保存间隔.Items.Add(ribbonDropDownItemImpl22);
            this.永久保存间隔.Items.Add(ribbonDropDownItemImpl23);
            this.永久保存间隔.Items.Add(ribbonDropDownItemImpl24);
            this.永久保存间隔.Items.Add(ribbonDropDownItemImpl25);
            this.永久保存间隔.Items.Add(ribbonDropDownItemImpl26);
            this.永久保存间隔.Items.Add(ribbonDropDownItemImpl27);
            this.永久保存间隔.Items.Add(ribbonDropDownItemImpl28);
            this.永久保存间隔.Items.Add(ribbonDropDownItemImpl29);
            this.永久保存间隔.Items.Add(ribbonDropDownItemImpl30);
            this.永久保存间隔.Label = "永久保存间隔";
            this.永久保存间隔.Name = "永久保存间隔";
            this.永久保存间隔.Text = null;
            this.永久保存间隔.TextChanged += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.永久保存间隔_TextChanged);
            // 
            // 保存原始文件
            // 
            this.保存原始文件.Checked = true;
            this.保存原始文件.Enabled = false;
            this.保存原始文件.Label = "保存原始文件";
            this.保存原始文件.Name = "保存原始文件";
            this.保存原始文件.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.保存原始文件_Click);
            // 
            // 关于
            // 
            this.关于.Items.Add(this.按钮_帮助);
            this.关于.Items.Add(this.打开配置文件);
            this.关于.Label = "关于";
            this.关于.Name = "关于";
            // 
            // 按钮_帮助
            // 
            this.按钮_帮助.Label = "帮助/弹窗";
            this.按钮_帮助.Name = "按钮_帮助";
            this.按钮_帮助.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.按钮_帮助_Click);
            // 
            // 打开配置文件
            // 
            this.打开配置文件.Enabled = false;
            this.打开配置文件.Label = "打开配置文件";
            this.打开配置文件.Name = "打开配置文件";
            this.打开配置文件.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.打开配置文件_Click);
            // 
            // 时钟1
            // 
            this.时钟1.Interval = 1000;
            this.时钟1.Tick += new System.EventHandler(this.时钟1_Tick);
            // 
            // 时钟2
            // 
            this.时钟2.Tick += new System.EventHandler(this.时钟2_Tick);
            // 
            // 时钟3
            // 
            this.时钟3.Interval = 500;
            this.时钟3.Tick += new System.EventHandler(this.时钟3_Tick);
            // 
            // Ribbon1
            // 
            this.Name = "Ribbon1";
            this.RibbonType = "Microsoft.Excel.Workbook";
            this.Tabs.Add(this.自动保存P);
            this.Load += new Microsoft.Office.Tools.Ribbon.RibbonUIEventHandler(this.Ribbon1_Load);
            this.自动保存P.ResumeLayout(false);
            this.自动保存P.PerformLayout();
            this.组件_首选项.ResumeLayout(false);
            this.组件_首选项.PerformLayout();
            this.选项1.ResumeLayout(false);
            this.选项1.PerformLayout();
            this.选项2.ResumeLayout(false);
            this.选项2.PerformLayout();
            this.关于.ResumeLayout(false);
            this.关于.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        internal Microsoft.Office.Tools.Ribbon.RibbonTab 自动保存P;
        internal Microsoft.Office.Tools.Ribbon.RibbonGroup 组件_首选项;
        internal Microsoft.Office.Tools.Ribbon.RibbonCheckBox 选择框_启动自动保存;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton 打开保存文件夹;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton 设置;
        internal Microsoft.Office.Tools.Ribbon.RibbonGroup 选项1;
        internal Microsoft.Office.Tools.Ribbon.RibbonComboBox 文件数;
        internal Microsoft.Office.Tools.Ribbon.RibbonComboBox 间隔时间;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton 保存位置;
        internal Microsoft.Office.Tools.Ribbon.RibbonGroup 选项2;
        internal Microsoft.Office.Tools.Ribbon.RibbonCheckBox 启动永久;
        internal Microsoft.Office.Tools.Ribbon.RibbonComboBox 永久保存间隔;
        internal Microsoft.Office.Tools.Ribbon.RibbonCheckBox 保存原始文件;
        internal Microsoft.Office.Tools.Ribbon.RibbonGroup 关于;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton 按钮_帮助;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton 打开配置文件;
        internal System.Windows.Forms.Timer 时钟1;
        internal System.Windows.Forms.Timer 时钟2;
        internal System.Windows.Forms.FolderBrowserDialog 文件夹对话框;
        internal System.Windows.Forms.Timer 时钟3;
    }

    partial class ThisRibbonCollection
    {
        internal Ribbon1 Ribbon1
        {
            get { return this.GetRibbon<Ribbon1>(); }
        }
    }
}
