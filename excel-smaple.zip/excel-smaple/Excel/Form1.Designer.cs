﻿
namespace Excel自动保存
{
    partial class 弹窗说明
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(弹窗说明));
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.启动功能 = new System.Windows.Forms.Button();
            this.不启动 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox1.Location = new System.Drawing.Point(12, 12);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox1.Size = new System.Drawing.Size(567, 228);
            this.textBox1.TabIndex = 11;
            this.textBox1.Text = resources.GetString("textBox1.Text");
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(12, 253);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(156, 16);
            this.checkBox1.TabIndex = 10;
            this.checkBox1.Text = "打勾后不在显示此对话框";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // 启动功能
            // 
            this.启动功能.Location = new System.Drawing.Point(214, 246);
            this.启动功能.Name = "启动功能";
            this.启动功能.Size = new System.Drawing.Size(145, 23);
            this.启动功能.TabIndex = 9;
            this.启动功能.Text = "启动自动保存功能";
            this.启动功能.UseVisualStyleBackColor = true;
            this.启动功能.Click += new System.EventHandler(this.启动功能_Click);
            // 
            // 不启动
            // 
            this.不启动.Location = new System.Drawing.Point(405, 246);
            this.不启动.Name = "不启动";
            this.不启动.Size = new System.Drawing.Size(145, 23);
            this.不启动.TabIndex = 8;
            this.不启动.Text = "不启动自动保存功能";
            this.不启动.UseVisualStyleBackColor = true;
            this.不启动.Click += new System.EventHandler(this.不启动_Click);
            // 
            // 弹窗说明
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(592, 281);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.启动功能);
            this.Controls.Add(this.不启动);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "弹窗说明";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "关于";
            this.Load += new System.EventHandler(this.弹窗说明_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button 启动功能;
        private System.Windows.Forms.Button 不启动;
    }
}