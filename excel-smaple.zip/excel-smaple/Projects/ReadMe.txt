﻿Task1——行求和，然后画出曲线图
随机生成100行100列个数，每个数位为0~9的整数，然后求每行的和，最后调用Chart，画出线状图。

Task2——求TFIDF值。
对于一个workbook有10个sheet，每个sheet随机产生100行*100列共10000个单词words，然后计算每个单词在每个文档的TFIDF值。
方便期间，我用100个数字（0~99）来代表不同的单词word，也就是为每个sheet随机了10000个数。

程序运行流程：
1.单击ActionsPane中的randData按钮，给每个sheet随机产生words（i.e.,0~99），
2.单机ActionsPane中calcTFIDF按钮，计算每个word在每个文档sheet的TFIDF值，结果输出值文件“E:\\resultFilename.txt"文件中。
  结果文件说明：文件共100行，10列。 行代表100个words(0~99)，列代表10个文档sheet。 第i行第j列表示的就是word (i-1) 在文档 j 中的TFIDF值。
  由于随机的数都在每个sheet趋于均匀分布，算出的TFIDF值也很接近。算TFIDF的公式有几个变种（参考wikipedia），自己用了最简单的。
  
  
  
备注：实验环境：VS2013+Office2013。 
两个程序只实现了简单的功能，有些地方考虑不周，抱歉。