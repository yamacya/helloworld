﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;
using Microsoft.Office.Tools.Excel;
using Microsoft.VisualStudio.Tools.Applications.Runtime;
using Excel = Microsoft.Office.Interop.Excel;
using Office = Microsoft.Office.Core;

namespace ExcelTask1
{
    public partial class Sheet1
    {
        Button randData = new Button();
        Button draw = new Button();
        Microsoft.Office.Tools.Excel.Chart sumfigure = null;
        private void Sheet1_Startup(object sender, System.EventArgs e)
        {
            randData.Text = "RandomData";
            randData.Click += new EventHandler(randData_Click);
            Globals.ThisWorkbook.ActionsPane.Controls.Add(randData);

            draw.Text = "DrawFigure";
            draw.Click += new EventHandler(draw_Click);
            Globals.ThisWorkbook.ActionsPane.Controls.Add(draw);
        }
        private void randData_Click(object sender, EventArgs e)
        {
            bool oldScreenUpdatingSetting = this.Application.ScreenUpdating;
            try
            {
                this.Application.ScreenUpdating = false;
                Random r = new Random();
                for (int i = 1; i < 101; ++i)
                {
                    string address = String.Format("A{0}:CV{0}", i);
                    Excel.Range ranges = Range[address, missing];
                    for (int j = 1; j < 101; ++j)
                    {
                        Excel.Range range = ranges.get_Item(j, missing) as Excel.Range;
                        range.Value2 = r.Next(10);
                    }
                }
            }
            finally
            {
                this.Application.ScreenUpdating = oldScreenUpdatingSetting;
            }
        }

        private void draw_Click(object sender, EventArgs e)
        {
            if (sumfigure == null)
            {                
                sumfigure = this.Controls.AddChart(25, 110, 800, 200, "sumfigure");
                //sumfigure.ChartType = Excel.XlChartType.xlColumnClustered;
                sumfigure.ChartType = Excel.XlChartType.xlLine;
                for (int i = 1; i < 101; ++i)
                {
                    string address = String.Format("CW{0}", i);
                    Excel.Range range = Range[address, missing];
                    range.Value2 = String.Format("=SUM(A{0}:CV{0}", i);
                }
                // Gets the cells that define the data to be charted.
                Excel.Range chartRange = this.get_Range("CW1", "CW100");
                sumfigure.SetSourceData(chartRange, missing);
            }
        }

        private void Sheet1_Shutdown(object sender, System.EventArgs e)
        {
        }

        #region VSTO 设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(Sheet1_Startup);
            this.Shutdown += new System.EventHandler(Sheet1_Shutdown);
        }

        #endregion

    }
}
