﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;
using Microsoft.Office.Tools.Excel;
using Microsoft.VisualStudio.Tools.Applications.Runtime;
using Excel = Microsoft.Office.Interop.Excel;
using Office = Microsoft.Office.Core;

namespace ExcelTask2
{
    public partial class ThisWorkbook
    {
        public int terms = 100;
        public int rows = 100;
        public int docs = 10;
        private string resultFilename = "e:\\result.txt";
        Button randData = new Button();
        Button calcTFIDF = new Button();
        Label resultfilename = new Label();

        private void ThisWorkbook_Startup(object sender, System.EventArgs e)
        {
            randData.Text = "RandomData";
            randData.Click += new EventHandler(randData_Click);
            Globals.ThisWorkbook.ActionsPane.Controls.Add(randData);

            calcTFIDF.Text = "calcTFIDF";
            calcTFIDF.Click += new EventHandler(calcTFIDF_Click);
            calcTFIDF.Enabled = false;
            Globals.ThisWorkbook.ActionsPane.Controls.Add(calcTFIDF);

            resultfilename.Text = "ResultFileName: " + resultFilename;
            resultfilename.Visible = false;
            Globals.ThisWorkbook.ActionsPane.Controls.Add(resultfilename);
        }

        private void randData_Click(object sender, EventArgs e)
        {
            bool oldScreenUpdatingSetting = this.Application.ScreenUpdating;
            try
            {
                this.Application.ScreenUpdating = false;
                Random r = new Random();
                foreach (Excel.Worksheet sheet in this.Worksheets)
                {
                    for (int i = 1; i <= rows; ++i)
                    {
                        string address = String.Format("A{0}:CV{0}", i);
                        Excel.Range ranges = sheet.Range[address, missing];
                        for (int j = 1; j < 101; ++j)
                        {
                            Excel.Range range = ranges.get_Item(j, missing) as Excel.Range;
                            range.Value2 = r.Next(100);
                        }
                    }
                }
                calcTFIDF.Enabled = true;
            }
            finally
            {
                this.Application.ScreenUpdating = oldScreenUpdatingSetting;
            }
        }

        private void calcTFIDF_Click(object sender, EventArgs e)
        {
            calcTFIDF.Enabled = false;
            randData.Enabled = false;
            int[,] statistic = new int[docs, terms];
            int sheetNo = 0;
            int totalcount = 0;
            foreach (Excel.Worksheet sheet in this.Worksheets)
            {
                int count = 0;
                for (int i = 1; i <= rows; ++i)
                {
                    string address = String.Format("A{0}:CV{0}", i);
                    Excel.Range ranges = sheet.Range[address, missing];
                    for (int j = 1; j < 101; ++j)
                    {
                        Excel.Range range = ranges.get_Item(j, missing) as Excel.Range;
                        statistic[sheetNo, (int)range.Value]++;
                        count++;
                    }
                }
                sheetNo++;
                Console.WriteLine("Total terms in {0} document = {1}", sheetNo, count);
                totalcount += count;
            }
            Console.WriteLine("Total terms = {0} ", totalcount);
            calc(statistic, totalcount);
            calcTFIDF.Enabled = true;
            randData.Enabled = true;
        }

        private void calc(int[,] statistic, int totalcount)
        {
            double[] idf = new double[terms];
            for (int i = 0; i < terms; ++i)
            {
                int count = 0;
                for (int j = 0; j < docs; ++j)
                {
                    if (statistic[j, i] > 0)
                    {
                        count++;
                    }
                }
                //idf[i] = Math.Log((double)docs / (double)(count+1)); //stand equation
                idf[i] = ((double)docs / (double)(count + 1));
            }
            double[,] tfidf = new double[terms, docs];
            for (int i = 0; i < terms; ++i)
            {
                for (int j = 0; j < docs; ++j)
                {
                    tfidf[i, j] = ((double)(statistic[j, i]) / (double)totalcount + 1) * idf[i];
                }
            }
            outputfile(tfidf);
        }
        private void outputfile(double[,] tfidf)
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < terms; ++i)
            {
                for (int j = 0; j < docs; ++j)
                {
                    sb.Append(String.Format("{0:0.00000000}",tfidf[i, j]) + "\t");
                }
                sb.AppendLine();
            }
            System.IO.StreamWriter file = new System.IO.StreamWriter(resultFilename);
            file.WriteLine(sb.ToString());
            file.Close();
            resultfilename.Visible = true;
        }
        private void ThisWorkbook_Shutdown(object sender, System.EventArgs e)
        {
        }

        #region VSTO 设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(ThisWorkbook_Startup);
            this.Shutdown += new System.EventHandler(ThisWorkbook_Shutdown);
        }

        #endregion

    }
}
