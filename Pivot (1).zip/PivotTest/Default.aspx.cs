﻿using System;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using HtmlPivot; //From the referenced Pivot.dll

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Advanced Pivot
        Pivot advPivot = new Pivot(DataTableForTesting);
        HtmlTable advancedPivot = advPivot.PivotTable("Sales Person", "Product", new string[] { "Sale Amount", "Quantity" });
        div1.Controls.Add(advancedPivot);

        //Simple Pivot
        Pivot pivot = new Pivot(DataTableForTesting);
        //override default style with css
        pivot.CssTopHeading = "Heading";
        pivot.CssLeftColumn = "LeftColumn";
        pivot.CssItems = "Items";
        pivot.CssTotals = "Totals";
        pivot.CssTable = "Table";

        HtmlTable simplePivot = pivot.PivotTable("Product", "Sales Person", "Sale Amount");
        div2.Controls.Add(simplePivot);
    }

    public DataTable DataTableForTesting
    {
        get
        {
            DataTable dt = new DataTable("Sales Table");
            dt.Columns.Add("Sales Person");
            dt.Columns.Add("Product");
            dt.Columns.Add("Quantity");
            dt.Columns.Add("Sale Amount");

            dt.Rows.Add(new object[] { "John", "Pens", 200, 350.00 });
            dt.Rows.Add(new object[] { "John", "Pencils", 400, 500.00 });
            dt.Rows.Add(new object[] { "John", "Notebooks", 100, 300.00 });
            dt.Rows.Add(new object[] { "John", "Rulers", 50, 100.00 });
            dt.Rows.Add(new object[] { "John", "Calculators", 120, 1200.00 });
            dt.Rows.Add(new object[] { "John", "Back Packs", 75, 1500.00 });
            dt.Rows.Add(new object[] { "Jane", "Pens", 225, 393.75 });
            dt.Rows.Add(new object[] { "Jane", "Pencils", 335, 418.75 });
            dt.Rows.Add(new object[] { "Jane", "Notebooks", 200, 600.00 });
            dt.Rows.Add(new object[] { "Jane", "Rulers", 75, 150.00 });
            dt.Rows.Add(new object[] { "Jane", "Calculators", 80, 800.00 });
            dt.Rows.Add(new object[] { "Jane", "Back Packs", 97, 1940.00 });
            dt.Rows.Add(new object[] { "Sally", "Pens", 202, 353.50 });
            dt.Rows.Add(new object[] { "Sally", "Pencils", 303, 378.75 });
            dt.Rows.Add(new object[] { "Sally", "Notebooks", 198, 600.00 });
            dt.Rows.Add(new object[] { "Sally", "Rulers", 98, 594.00 });
            dt.Rows.Add(new object[] { "Sally", "Calculators", 80, 800.00 });
            dt.Rows.Add(new object[] { "Sally", "Back Packs", 101, 2020.00 });
            dt.Rows.Add(new object[] { "Sarah", "Pens", 112, 196.00 });
            dt.Rows.Add(new object[] { "Sarah", "Pencils", 245, 306.25 });
            dt.Rows.Add(new object[] { "Sarah", "Notebooks", 198, 594.00 });
            dt.Rows.Add(new object[] { "Sarah", "Rulers", 50, 100.00 });
            dt.Rows.Add(new object[] { "Sarah", "Calculators", 66, 660.00 });
            dt.Rows.Add(new object[] { "Sarah", "Back Packs", 50, 2020.00 });

            return dt;
        }
    }
}
