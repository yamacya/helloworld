# -*- coding: utf-8 -*-
"""
Created on Wed Jan 25 18:16:34 2023

@author: zjdav
"""
import os
import datetime
import zipfile

ARCHIVE_DAYS = 2
CURRENT_PATH = "D:\\study-project\\python\\searchAndBackup"
BACKUP_PATH = "D:\\study-project\\python\\searchAndBackup\\backup"
listDelFiles = ['']
path="."
print(os.listdir(path))

def zip_file(src_path):
    new_zip_name = BACKUP_PATH + "\\" + src_path +'.zip'
    nz = zipfile.ZipFile(new_zip_name,'w',zipfile.ZIP_DEFLATED)
    #for dirpath,dirnames,filenames in os.walk(scr_path):
        #fpath=dirpath.replace(scr_path,'')
        #fpath=
        #nz.write(os.path.join(dirpath,filename))
    nz.write(CURRENT_PATH + "\\" +  src_path)
    nz.close()
    print('File is closed.')
    

#today's date
todayDateStr = datetime.date.today().strftime("%Y%m%d")
print("Today is " + todayDateStr)

todayYear = int(todayDateStr[:4])
todayMonth = int(todayDateStr[4:6])
todayDay = int(todayDateStr[6:])

todayDate = datetime.date(todayYear, todayMonth, todayDay)

for item in os.listdir(path):
    if not os.path.isdir(item) and "_" in item:
        if '.txt' in item.split('_')[2]:
            dateGeneratedStr = item.split('_')[2].removesuffix('.txt')
            dateGeneratedYear = int(dateGeneratedStr[:4])
            dateGeneratedMonth = int(dateGeneratedStr[4:6])
            dateGeneratedDay = int(dateGeneratedStr[6:])
            dateGenerated = datetime.date(dateGeneratedYear,dateGeneratedMonth,dateGeneratedDay)
            
            if (todayDate - dateGenerated).days > ARCHIVE_DAYS:
                #fd = zip_file(item)
                listDelFiles.append(os.path.abspath(item))
                #os.close(zip_file(item))
                
for delFile in listDelFiles:
    if len(delFile) > 0:
        print(delFile)
        os.system(f"attrib -r {delFile}")
        os.remove(delFile)
                