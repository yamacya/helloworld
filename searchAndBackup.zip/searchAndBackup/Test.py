# -*- coding: utf-8 -*-
"""
Created on Wed Jan 25 21:33:22 2023

@author: zjdav
"""

import os

os.remove("D:\\study-project\\python\\searchAndBackup\\1.txt")